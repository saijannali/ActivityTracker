//
//  ContentView.swift
//  ImpluseSolutions
//
//  Created by Sai Jannali on 8/19/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        MainTabView()
    }
}

#Preview {
    ContentView()
}
